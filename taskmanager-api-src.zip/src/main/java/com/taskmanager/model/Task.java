package com.taskmanager.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="Tarefas")
@Getter
@Setter
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(name="presentationOrder", nullable = false)
    private int presentationOrder;
    @Column(name="name", nullable = false, unique = true)
    private String name;
    @Column(name="value", nullable = false)
    private double value;

    public Task(long id, String name, int presentationOrder, double value) {
        this.name = name;
        this.id = id;
        this.presentationOrder = presentationOrder;
        this.value = value;
    }

    @Override
    public String toString() {
        return this.presentationOrder + " - " + this.name + " - " + this.value;
    }
}
